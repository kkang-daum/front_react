const Home = () => {
  return (
    <div className="card card-body">
      <h2>Home</h2>
    </div>
  );
};
export default Home;
